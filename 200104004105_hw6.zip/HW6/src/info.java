public class info {
    int count;
    String[] words;

    public info(int count, String[] words) {
        this.count = count;
        this.words = words;
    }

    public info() {

    }

    public int getCount() {
        return count;
    }
    public void setCount(){
        this.count = 0;
    }
    public void setCount(int count) {
        this.count = count;
    }

    public String[] getWords() {
        return words;
    }

    public void setWords(String[] words) {
        this.words = words;
    }
    public void push(String word) {
        count++;
        String[] newWords = new String[words.length + 1];
        System.arraycopy(words, 0, newWords, 0, words.length);
        newWords[newWords.length - 1] = word;
        words = newWords;
    }


}
