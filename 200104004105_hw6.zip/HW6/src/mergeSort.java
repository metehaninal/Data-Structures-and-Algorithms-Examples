import java.util.*;

public class mergeSort {
    private myMap originalMap;
    private myMap sortedMap;

    public mergeSort(myMap map) {
        originalMap = map;
        sortedMap = new myMap();
        sortedMap = sortMap(originalMap);
    }

    private myMap sortMap(myMap map) {
        if (map.size() <= 1) {
            return map;
        }
        int mid = map.size() / 2;
        myMap left = new myMap();
        myMap right = new myMap();
        int i = 0;
        for (Map.Entry<String, info> entry : map.getMap().entrySet()) {
            if (i < mid) {
                left.put(entry.getKey(), entry.getValue());
            } else {
                right.put(entry.getKey(), entry.getValue());
            }
            i++;
        }
        left = sortMap(left);
        right = sortMap(right);
        return merge(left, right);
    }

    private myMap merge(myMap left, myMap right) {
        myMap result = new myMap();
        while (!left.getMap().isEmpty() && !right.getMap().isEmpty()) {
            if (left.get(left.keySet().iterator().next()).count <= right.get(right.keySet().iterator().next()).count) {
                result.put(left.keySet().iterator().next(), left.getMap().remove(left.keySet().iterator().next()));
            } else {
                result.put(right.keySet().iterator().next(), right.getMap().remove(right.keySet().iterator().next()));
            }
        }
        if (!left.getMap().isEmpty()) {
            result.getMap().putAll((Map<? extends String, ? extends info>) left);
        }
        if (!right.getMap().isEmpty()) {
            result.getMap().putAll((Map<? extends String, ? extends info>)right);
        }
        return result;
    }
}
