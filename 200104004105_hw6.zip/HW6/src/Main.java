import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("enter a string: ");
        String str;
        str = sc.nextLine();
        System.out.println("original string is : "+ str);
        System.out.println("preprocessing string is : "+ processString(str));

        int numUniqueLetters = countUniqueLetters(processString(str));

        int mapSize = countUniqueLetters(processString(str));
        System.out.println("mapsize = "+ mapSize);
        myMap myMapInstance = new myMap(mapSize,processString(str) );
        myMapInstance.buildMap(processString(str),mapSize);


        printMap(myMapInstance.getMap());

    }
    /**
     * Processes a string by converting all characters to lowercase and removing
     * any non-letter characters (excluding spaces).
     *
     * @param input the input string to be processed
     * @return a new string containing only lowercase letters and spaces
     */
    public static String processString(String input) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetter(c) || c == ' ') {
                sb.append(Character.toLowerCase(c));
            }
        }
        return sb.toString();
    }

    /**
     * Returns the count of unique letters in a given string.
     *
     * @param str the string to count unique letters from
     * @return the count of unique letters in the given string
     */
    public static int countUniqueLetters(String str) {
        Set<Character> uniqueChars = new HashSet<>();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c != ' ') {
                uniqueChars.add(c);
            }
        }
        return uniqueChars.size();
    }
    /**
     * Prints the contents of a given LinkedHashMap with keys of type String and values of type info.
     *
     * @param map the LinkedHashMap to print
     */
    public static void printMap(LinkedHashMap<String, info> map) {
        for (Map.Entry<String, info> entry : map.entrySet()) {
            String letter = entry.getKey();
            info letterInfo = entry.getValue();
            int count = letterInfo.count;
            String[] words = letterInfo.words;
            System.out.print("Letter: " + letter + " - Count: " + count + " - Words: [");
            for (int i = 0; i < count; i++) {
                System.out.print(words[i]);
                if (i != count - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("]");
        }
    }


}
