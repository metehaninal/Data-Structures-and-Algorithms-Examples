import java.util.Arrays;
import java.util.Set;
import java.util.LinkedHashMap;

public class myMap {
    int mapSize;
    String str;
    LinkedHashMap<String,info> map;

    public myMap(int mapSize, String str) {
        this.mapSize = mapSize;
        this.str = str;
        this.map = map;
    }

    public myMap() {

    }

    public Set<String> keySet() {
        return map.keySet();
    }

    public info get(String key) {
        return map.get(key);
    }

    public void put(String key, info value) {
        map.put(key, value);
    }
    public int getMapSize() {
        return mapSize;
    }

    public void setMapSize(int mapSize) {
        this.mapSize = mapSize;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public LinkedHashMap<String, info> getMap() {
        return this.map;
    }

    public void setMap(LinkedHashMap<String, info> map) {
        this.map = map;
    }

    /**
     * Builds a LinkedHashMap with keys of type String and values of type info, representing the count and
     * words that start with each unique letter in a given string.
     *
     * @param str the string to build the map from
     * @param mapSize the initial size of the map
     * @return the LinkedHashMap with the count and words that start with each unique letter in the given string
     */

    public LinkedHashMap<String, info> buildMap(String str, int mapSize) {
        this.map = new LinkedHashMap<>(mapSize);

        String[] words = str.split("\\s+");
        for (String word : words) {
            for (char c : word.toCharArray()) {
                String letter = String.valueOf(c);
                if (!map.containsKey(letter)) {
                    map.put(letter, new info());
                }
                info letterInfo = map.get(letter);
                letterInfo.count++;
                if (letterInfo.words == null) {
                    letterInfo.words = new String[1];
                    letterInfo.words[0] = word;
                } else {
                    String[] newWords = new String[letterInfo.count];
                    System.arraycopy(letterInfo.words, 0, newWords, 0, letterInfo.count - 1);
                    newWords[letterInfo.count - 1] = word;
                    letterInfo.words = newWords;
                }
            }
        }

        return this.map;
    }


    public int size() {
        return map.size();
    }



}

