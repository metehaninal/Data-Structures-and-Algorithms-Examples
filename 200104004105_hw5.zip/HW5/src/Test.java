import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Test {


    public static void main(String[] args) {
        String fileName = "tree.txt";
        ArrayList<ArrayList<String>> array2D = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(";");
                ArrayList<String> row = new ArrayList<>(Arrays.asList(values));
                array2D.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // build the tree
        Node root = new Node("root");
        Node parent = root;

        for (ArrayList<String> row : array2D) {
            for (int i = 1; i < row.size(); i++) {
                String value = row.get(i);
                Node child = null;
                for (Node node : parent.getChildren()) {
                    if (node.getValue().equals(value)) {
                        child = node;
                        break;
                    }
                }
                if (child == null) {
                    child = new Node(value);
                    parent.addChild(child);
                    child.setParent(parent);
                }
                parent = child;
            }
            parent = root;
        }

        // create JTree
        DefaultMutableTreeNode jRoot = new DefaultMutableTreeNode(root.getValue());
        addNodes(jRoot, root);

        JTree tree = new JTree(jRoot);
        tree.setRootVisible(true);

        JScrollPane scrollPane = new JScrollPane(tree);

        JFrame frame = new JFrame("JTree Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(scrollPane);
        frame.pack();
        frame.setVisible(true);



        // B part
        // perform BFS to search for a value in the tree
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a value to search with BFS :");
        String target = sc.nextLine(); // taking input to search for
        Node foundNode = breadthFirstSearch(root, target);


        //C part
        System.out.println("PART C");
        System.out.print("Enter a value to search with DFS :");
        String searchValue = sc.nextLine();
        depthFirstSearch(root,searchValue);
    }
    /**
     * Performs a depth-first search on the tree to find the specified search value.
     *
     * @param node The current node being searched.
     * @param searchValue The value being searched for.
     * @return True if the search value is found in the tree, false otherwise.
     */
    private static boolean depthFirstSearch(Node node, String searchValue) {
        if (node == null) {
            return false;
        }

        System.out.println("Step " + node.getDepth() + ": " + node.getValue());

        if (node.getValue().equals(searchValue)) {
            System.out.println(searchValue + " found!");
            return true;
        }

        for (Node child : node.getChildren()) {
            if (depthFirstSearch(child, searchValue)) {
                return true;
            }
        }

        return false;
    }

    /**
     Perform breadth-first search on a tree starting from the given root node, looking for a node with the given value.
     @param root the root node of the tree to search in
     @param target the value to search for
     @return the node with the given value, or null if the value is not found in the tree
     */
    private static Node breadthFirstSearch(Node root, String target) {
        Queue<Node> queue = new LinkedList<>();
        queue.offer(root);

        int step = 0;
        while (!queue.isEmpty()) {
            step++;
            Node current = queue.poll();
            System.out.println("Step " + step + ": " + current.getValue());
            if (current.getValue().equals(target)) {
                System.out.print(target + " found");
                return current;
            }
            for (Node child : current.getChildren()) {
                queue.offer(child);
            }
        }

        System.out.println("Could not find node with value: " + target);
        return null;
    }

    /**
     Recursively adds child nodes to a given JTree node from a given Node.
     @param jNode the DefaultMutableTreeNode to which child nodes are added
     @param node the parent Node whose children will be added to jNode
     */
    private static void addNodes(DefaultMutableTreeNode jNode, Node node) {
        for (Node child : node.getChildren()) {
            DefaultMutableTreeNode jChild = new DefaultMutableTreeNode(child.getValue());
            jNode.add(jChild);
            addNodes(jChild, child);
        }
    }


}
