import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

/**
 * This class represents a node in a tree data structure.
 */
public class Node {

    /**
     * The value associated with the node.
     */
    private String value;

    /**
     * The parent node of this node.
     */
    private Node parent;

    /**
     * The list of children nodes of this node.
     */
    private ArrayList<Node> children;

    /**
     * Constructor for creating a new Node instance.
     *
     * @param value the value associated with the node.
     */
    public Node(String value) {
        this.value = value;
        this.parent = null;
        this.children = new ArrayList<>();
    }

    /**
     * Returns the value associated with the node.
     *
     * @return the value associated with the node.
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value associated with the node.
     *
     * @param value the new value to set.
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Returns the parent node of this node.
     *
     * @return the parent node of this node.
     */
    public Node getParent() {
        return parent;
    }

    /**
     * Sets the parent node of this node.
     *
     * @param parent the new parent node to set.
     */
    public void setParent(Node parent) {
        this.parent = parent;
    }

    /**
     * Returns the list of children nodes of this node.
     *
     * @return the list of children nodes of this node.
     */
    public ArrayList<Node> getChildren() {
        return children;
    }

    /**
     * Adds a child node to the list of children nodes of this node.
     *
     * @param child the child node to add.
     */
    public void addChild(Node child) {
        this.children.add(child);
    }

    /**
     * Returns the depth of the node in the tree.
     *
     * @return the depth of the node in the tree.
     */
    public int getDepth() {
        if (parent == null) {
            return 0;
        } else {
            return parent.getDepth() + 1;
        }
    }
}

