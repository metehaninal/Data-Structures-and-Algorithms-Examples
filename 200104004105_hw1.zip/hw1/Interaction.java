package hw1;
public class Interaction {
    private int interactionID;
    private int accountID;
    private int postID;

    public Interaction(int interactionID, int accountID, int postID) {
        this.interactionID = interactionID;
        this.accountID = accountID;
        this.postID = postID;
    }

    public Interaction() {
    }

    
    /** 
     * @return int
     */
    public int getInteractionID() {
        return this.interactionID;
    }

    public void setInteractionID(int interactionID) {
        this.interactionID = interactionID;
    }

    public int getAccountID() {
        return this.accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public int getPostID() {
        return this.postID;
    }

    public void setPostID(int postID) {
        this.postID = postID;
    }
    


}
