package hw1;
public class Post {
    
    private String content;
    private int postID;
    private int accountID;
    private String[] likes;
    private String[] comments;

    public Post(String content, int postID, int accountID, String[] likes, String[] comments) {
        this.content = content;
        this.postID = postID;
        this.accountID = accountID;
        this.likes = likes;
        this.comments = comments;
    }

    public Post() {
    }

    
    /** 
     * @return int
     */
    public int getPostID() {
        return this.postID;
    }

    
    /** 
     * @param postID
     */
    public void setPostID(int postID) {
        this.postID = postID;
    }

    public int getAccountID() {
        return this.accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public String[] getLikes() {
        return this.likes;
    }

    public void setLikes(String[] likes) {
        this.likes = likes;
    }

    public String[] getComments() {
        return this.comments;
    }

    public void setComments(String[] comments) {
        this.comments = comments;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
