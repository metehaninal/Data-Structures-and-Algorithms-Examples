package hw1;
public class Account {
    static int numOfFollowers = 0;
    static int numOfFollowings = 0;
    static int numOfMessages = 0;
    static int numOfPosts = 0;

    private int accountID;
    private String username;
    private String birthdate;
    private String location;
    private Post[] posts;
    private Message[] messages = new Message[1];
    private String[] followers = new String[1];
    private String[] following = new String[1];

    
    /** 
     * @return boolean
     */
    public boolean login(){
        System.out.println("Logging into an account: "+ this.username);
        return true;
    }
    public Account(int accountID, String username, String birthdate, String location, Post[] posts, Message[] messages, String[] followers, String[] following) {
        this.accountID = accountID;
        this.username = username;
        this.birthdate = birthdate;
        this.location = location;
        this.posts = posts;
        this.messages = messages;
        this.followers = followers;
        this.following = following;
        System.out.println("An account with username " + this.username + " has been created");
    }

    public Account() {
    }

    
    /** 
     * @return int
     */
    public int getAccountID() {
        return this.accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getBirthdate() {
        return this.birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Post[] getPosts() {
        return this.posts;
    }

    public void setPosts(Post[] posts) {
        this.posts = posts;
    }

    public Message[] getMessages() {
        return this.messages;
    }

    public void setMessages(Message[] messages) {
        this.messages = messages;
    }

    public String[] getFollowers() {
        return this.followers;
    }

    public void setFollowers(String[] followers) {
        this.followers = followers;
    }

    public String[] getFollowing() {
        return this.following;
    }

    public void setFollowing(String[] following) {
        this.following = following;
    }

    public void viewProfile(){
        System.out.println("UserID: "+this.accountID);
        System.out.println("username: "+this.username);
        System.out.println("Location: "+this.location);
        System.out.println("Birthdate: " + this.birthdate);
        if(this.followers.equals(null) ){
            System.out.println(this.username+"is following ("+ following.length + ") and has ("+ followers.length +") followers");
        }else if(this.following.equals(null)){
            System.out.println(this.username+"is following (0) and has ("+ followers.length +") followers");
        }else{
            System.out.println(this.username + "is following (" + following.length + ") and has (" + followers.length+") followers");
        }
        
    }
    
    public void printFollowers(Account acc){
        for (int i = 0; i < acc.followers.length; i++) {
            if(acc.followers[i].equals("0") || acc.followers[i].equals(null) ){
                System.out.print(acc.followers[i]);
            }
        }
    }

    /*adding posts */
    public Post[] addPost(Post x) {
        if(numOfPosts == 0){
            this.posts = new Post[1];
            this.posts[0] = x;
            ++numOfPosts;
            return this.posts;
        }else{
            int i;
            int n = numOfPosts;
            // create a new array of size n+1
            Post newarr[] = new Post[numOfPosts + 1];
            // insert the elements from
            // the old array into the new array
            // insert all elements till n
            // then insert x at n+1
            for (i = 0; i < numOfPosts; i++){
                newarr[i] = this.posts[i];
            }
            newarr[n] = x;
            this.posts = new Post[numOfPosts + 1];
            this.posts = newarr;
            ++numOfPosts;
            return this.posts;
        }
    }
    /*viewing posts */
    public void viewPosts(){
        System.out.println("viewing "+ this.username+"'s post's ...");
        for (int i = 0; i <this.posts.length; i++) {
            System.out.println("Post ID: "+this.posts[i].getPostID()+" "+ this.username + ": "+this.posts[i].getContent() );
        }
    }
}
