package hw1;
public class Comment extends Interaction {

    private String content;
    
    /** 
     * @return String
     */
    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    
    public Comment(int interactionID, int accountID, int postID,String content) {
        super(interactionID, accountID, postID);
        this.content = content;
        
    }
    
}
