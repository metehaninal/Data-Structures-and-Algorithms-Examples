package hw1;
public class TestClass1 {
    
    
    public static void main(String[] args) {
        Account account1 = new Account(1, "sibelGulmez", "16.09.1991", "Kocaeli", null, null, null, null);
        Account account2 = new Account(2, "gizemsungu", "23.06.1983", "İstanbul", null, null, null, null);
        Account account3 = new Account(3, "gokhankaya", "04.10.1970", "İstanbul", null, null, null, null);
        Post post1 = new Post("hello! I like Java", 1, 1, null, null);
        Post post2 = new Post("Java means coffee", 2, 1, null, null);
        Like like1 = new Like(1, 1, 1);
        Like like2 = new Like(2, 1, 2);
        account1.addPost(post1);
        account1.addPost(post2);
        account1.viewPosts();
        account1.viewProfile();

    }
}
