package hw1;
public class Like extends Interaction {

    public Like(int interactionID, int accountID, int postID) {
        super(interactionID, accountID, postID);
        
    }

    public Like() {
    }
            
}
