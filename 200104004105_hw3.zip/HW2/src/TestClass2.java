public class TestClass2 {
    public static void main(String[] args) {
        Account gizemsungu = new Account(1,"gizemsungu","17.07.1979","Samsun");
        gizemsungu.login();
        Post post1 = new Post("hello! I like Java", 1, 1);
        Post post2 = new Post("Java means coffee", 2, 1);
        gizemsungu.addPost(post1);
        gizemsungu.addPost(post2);
        gizemsungu.logout();

        /*---------------------------------------*/

        Account sibelgulmez = new Account(2, "sibelGulmez", "16.09.1991", "Kocaeli");
        sibelgulmez.login();
        sibelgulmez.viewProfile(gizemsungu);
        Like like1 = new Like(sibelgulmez, 1, 1);
        post1.addLike(like1);
        sibelgulmez.logout();

        /*------------------------------------------*/

        Account gokhankaya = new Account(3, "gokhankaya", "04.10.1970", "Ankara");
        gokhankaya.login();
        gokhankaya.viewProfile(gizemsungu);
        Message newMessage = new Message(1, gokhankaya.getAccountID(), gizemsungu.getAccountID(), "hello");
        gokhankaya.sendMessageTo(gizemsungu,newMessage);
        gokhankaya.logout();

        /*------------------------------------------*/

        gizemsungu.login();
        gizemsungu.viewProfile(gizemsungu);
        gizemsungu.viewMessages("inbox");
        gizemsungu.logout();



    }
}
