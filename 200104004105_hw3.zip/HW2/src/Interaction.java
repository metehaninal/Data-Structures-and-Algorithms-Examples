public class Interaction {
    private int interactionID;
    private Account account;
    private int postID;

    public Interaction() {
    }

    public Interaction(Account account,int interactionID, int postID) {
        this.interactionID = interactionID;
        this.account = account;
        this.postID = postID;
    }

    /**
     * @return int
     */
    public int getInteractionID() {
        return this.interactionID;
    }
    public void setInteractionID(int interactionID) {
        this.interactionID = interactionID;
    }
    public Account getAccount() {
        return account;
    }
    public void setAccount(Account account) {
        this.account = account;
    }
    public int getPostID() {
        return this.postID;
    }
    public void setPostID(int postID) {
        this.postID = postID;
    }
}
