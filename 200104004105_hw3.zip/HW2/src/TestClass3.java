public class TestClass3 {
    public static void main(String[] args) {
        Account gizemsungu = new Account(1,"gizemsungu","17.07.1979","Samsun");
        Account sibelgulmez = new Account(2, "sibelGulmez", "16.09.1991", "Kocaeli");
        Account gokhankaya = new Account(3, "gokhankaya", "04.10.1970", "Ankara");
        gizemsungu.login();
        gizemsungu.blockAcc(sibelgulmez);
        gizemsungu.logout();

        sibelgulmez.login();
        sibelgulmez.viewProfile(gizemsungu);
        Message newMessage = new Message(1, sibelgulmez.getAccountID(), gizemsungu.getAccountID(), "ban request!");
        sibelgulmez.sendMessageTo(gizemsungu,newMessage);


    }
}
