import java.util.ArrayList;

public class Post {
    private String content;
    private int postID;
    private int accountID;
    private ArrayList<Like> likes = new ArrayList<>();
    private ArrayList<Comment> comments = new ArrayList<>();

    public Post(String content, int postID, int accountID) {
        this.content = content;
        this.postID = postID;
        this.accountID = accountID;

    }
    public Post() {
    }
    /**
     * @return int
     */
    public int getPostID() {
        return this.postID;
    }

    /**
     * @param postID
     */
    public void setPostID(int postID) {
        this.postID = postID;
    }

    public int getAccountID() {
        return this.accountID;
    }

    /**
     *
     * @param accountID
     */
    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public ArrayList<Like> getLikes() {
        return likes;
    }

    /**
     *
     * @param likes
     */
    public void setLikes(ArrayList<Like> likes) {
        this.likes = likes;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    /**
     *
     * @param comments
     */
    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    public String getContent() {
        return content;
    }

    /**
     *
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
    }

    public void addLike(Like newLike){
        this.likes.add(newLike);
    }
    public void addComment(Comment newComment){
        this.comments.add(newComment);
    }

}
