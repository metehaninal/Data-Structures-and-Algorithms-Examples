public class TestClass1 {
    public static void main(String[] args) {
        
        Account sibelgulmez = new Account(1, "sibelGulmez", "16.09.1991", "Kocaeli");
        Account gizemsungu = new Account(2, "gizemsungu", "23.06.1983", "İstanbul");
        Account gokhankaya = new Account(3, "gokhankaya", "04.10.1970", "Ankara");
        sibelgulmez.login(); // step2
        Post post1 = new Post("hello! I like Java", 1, 1);
        Post post2 = new Post("Java means coffee", 2, 1);
        sibelgulmez.addPost(post1);
        sibelgulmez.addPost(post2); //step3
        sibelgulmez.follow(gizemsungu);
        sibelgulmez.follow(gokhankaya); //step4
        sibelgulmez.logout(); //s5

        gokhankaya.login(); //s6
        gokhankaya.viewProfile(sibelgulmez);
        gokhankaya.viewPosts(sibelgulmez);

        Like like1 = new Like(gokhankaya, 1, 1);
        post1.addLike(like1); //s9
        Comment comment1 = new Comment(gokhankaya, 2, 1,"firs comment!");
        post1.addComment(comment1); //s10
        gokhankaya.follow(sibelgulmez);
        gokhankaya.follow(gizemsungu);//s11

        Message newMessage = new Message(1, gokhankaya.getAccountID(), gizemsungu.getAccountID(), "hello");
        gokhankaya.sendMessageTo(gizemsungu,newMessage);
        gokhankaya.logout(); //s13

        gizemsungu.login();
        gizemsungu.numOfMessages(); //s15 16
        gizemsungu.viewMessages("inbox"); //s17
        gizemsungu.viewProfile(sibelgulmez); //s18
        gizemsungu.viewPosts(sibelgulmez); //s19
        sibelgulmez.showInteractions();







    }
}
