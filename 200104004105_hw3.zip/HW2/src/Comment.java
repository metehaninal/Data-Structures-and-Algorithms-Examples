public class Comment extends Interaction{
    private String content;
    /**
     * @return String
     */
    public String getContent() {
        return this.content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public Comment(Account account, int interactionID, int postID, String content) {
        super(account, interactionID, postID);
        this.content = content;
    }
}
