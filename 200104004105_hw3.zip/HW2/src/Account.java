import java.util.ArrayList;

public class Account {

    private boolean isAccountExists = false;
    private int accountID;
    private String username;
    private String birthdate;
    private String location;
    private ArrayList<Account> blockedAccounts = new ArrayList<>();

    private static Account loggedInAccount = null;  // static variable to store logged-in account

    private ArrayList<Post> posts = new ArrayList<>();
    private ArrayList<Message> inbox = new ArrayList<>();
    private ArrayList<Message> outbox = new ArrayList<>();
    private ArrayList<Account> followers = new ArrayList<>();
    private ArrayList<Account> following = new ArrayList<>();

    /** login method
     *
     * @return
     */
    public boolean login() {
        if (loggedInAccount == null) {  // check if no account is logged in
            loggedInAccount = this;  // set this account as the logged-in account
            System.out.println("Logged in successfully as " + this.username);
            System.out.println("----------------------------");
            return true;
        } else {  // another account is already logged in
            System.out.println("Cannot log in. Another account is already logged in.");
            System.out.println("----------------------------");
            return false;
        }
    }

    // logout method
    public static void logout() {
        loggedInAccount = null;  // clear the logged-in account
        System.out.println("Logged out successfully.");
        System.out.println("----------------------------");
    }

    public Account(int accountID, String username, String birthdate, String location) {
        this.accountID = accountID;
        this.username = username;
        this.birthdate = birthdate;
        this.location = location;
        this.isAccountExists = true;
        System.out.println("An account with username " + this.username + " has been created");
        System.out.println("----------------------------");
    }

    public void blockAcc(Account acc){
        System.out.println(acc.username + " is blocked!!");
        this.blockedAccounts.add(acc);
    }
    /**
     * @return int
     */
    public int getAccountID() {
        return this.accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getBirthdate() {
        return this.birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public ArrayList<Post> getPosts() {
        return posts;
    }

    public void setPosts(ArrayList<Post> posts) {
        this.posts = posts;
    }


    public ArrayList<Account> getFollowers() {
        return followers;
    }

    public void setFollowers(ArrayList<Account> followers) {
        this.followers = followers;
    }

    public ArrayList<Account> getFollowing() {
        return following;
    }

    public void setFollowing(ArrayList<Account> following) {
        this.following = following;
    }

    public ArrayList<Message> getInbox() {
        return inbox;
    }

    public void setInbox(ArrayList<Message> inbox) {
        this.inbox = inbox;
    }

    public ArrayList<Message> getOutbox() {
        return outbox;
    }

    public void setOutbox(ArrayList<Message> outbox) {
        this.outbox = outbox;
    }
    public ArrayList<Account> getBlockedAccounts() {
        return blockedAccounts;
    }

    public void setBlockedAccounts(ArrayList<Account> blockedAccounts) {
        this.blockedAccounts = blockedAccounts;
    }

    /**
     * viewing Profile
     */

    public void viewProfile(Account acc) {
        if (acc.blockedAccounts.contains(this)){ // if account is blocked print message!
            System.out.println(acc.username + " is blocked !!");
        }else{
            System.out.println("UserID: " + acc.accountID);
            System.out.println("username: " + acc.username);
            System.out.println("Location: " + acc.location);
            System.out.println("Birthdate: " + acc.birthdate);
            System.out.println(acc.username + " is following (" + acc.following.size() + ") accounts and has (" + acc.followers.size() + ") followers");
            if (acc.following.size() > 0){
                System.out.print(acc.username + " is following: ");
                for (int i = 0; i < acc.following.size(); i++) {
                    if (i==0)
                        System.out.print(acc.following.get(i).username);
                    else
                        System.out.print(","+acc.following.get(i).username);
                }
                System.out.println();
            }
            if (acc.followers.size() > 0){
                System.out.print("the followers of "+acc.username + " is/are: ");
                for (int i = 0; i < acc.followers.size(); i++) {
                    if (i==0){
                        System.out.print(acc.followers.get(i).username);
                    }else
                        System.out.print(","+acc.followers.get(i).username);
                }
                System.out.println();
            }
            System.out.println(acc.username +" has " + acc.posts.size() + " posts");
            System.out.println("----------------------------");
        }
    }

    /**
     * adding posts
     **/
    public ArrayList<Post> addPost(Post x) {
        this.posts.add(x);
        return this.posts;
    }

    /**
     * viewing posts */
    public void viewPosts(Account acc) {
        System.out.println("viewing " + acc.username + "'s post's ...");
        for (Post post : acc.posts) {
            System.out.println("Post ID: " + post.getPostID() + " " + acc.username + ": " + post.getContent());
        }
        System.out.println("----------------------------");
    }

    /**
     * add follower and followings to lists
     * @param acc
     * @return
     */
    public void follow(Account acc){
        this.following.add(acc);
        acc.followers.add(this);
    }

    public void unFollow(Account acc){
        System.out.println("unfollowing "+acc.username);
        this.following.remove(acc);
        acc.followers.remove(acc);
    }


    /**
     * if receiver account exists then send message
     * @param acc
     * @param newMessage
     */
    public void sendMessageTo(Account acc,Message newMessage){
        if (acc.blockedAccounts.contains(this)){
            System.out.println(acc.username+" is blocked! you cannot send a message");
        }else{
            if (acc.isAccountExists == true){
                this.outbox.add(newMessage);
                acc.inbox.add(newMessage);
            }else
                System.out.println("ERROR! there is no such an account!!!");
        }
    }

    public void numOfMessages(){
        System.out.println("There is/are "+this.inbox.size()+" messages in inbox");
        System.out.println("There is/are "+this.outbox.size()+" messages in inbox");
        System.out.println("------------------------");
    }

    /**
     * according to box type >>> print them
     * @param boxType
     */
    public void viewMessages(String boxType){
        if (boxType.equals("inbox")){
            System.out.println("inbox messages:");
            for (int i = 0; i < this.inbox.size(); i++) {
                System.out.println("->"+this.inbox.get(i).getContent()); //traverse in inbox contents
            }
        }else {
            System.out.print("outbox messages:");
            for (int i = 0; i < this.outbox.size(); i++) {
                System.out.println(this.outbox.get(i).getContent()); //traverse in inbox contents
            }
        }
        System.out.println("------------------------");
    }

    /**
     * printing interactions of post
     * @param post
     */
    public void printInteraction(Post post){
        System.out.println("(PostID: "+post.getPostID()+") "+ post.getContent());
        if (post.getLikes().size() == 0){ //checking likes of post
            System.out.println("The post has no likes.");
        }else{
            System.out.print("The post was liked by following accounts:");
            for (int i = 0; i < post.getLikes().size(); i++) {
                System.out.print(post.getLikes().get(i).getAccount().username+",");
            }
        }

        if (post.getComments().size() == 0){
            System.out.println("The post has no comments.");
        }else{
            System.out.print("\nThe post has "+ post.getComments().size() + " comment(s) :" );
            for (int i = 0; i < post.getComments().size(); i++) {
                System.out.print(post.getComments().get(i).getAccount().username+",");
            }
        }
        System.out.println("\n--------------------------------");
    }

    /**
     * show all interactions
     */
    public void showInteractions(){
        System.out.println("viewing "+this.username+"'s interactions");
        for (Post post: this.posts) {
            printInteraction(post);
        }
    }

    //end of class
}

