public class Like extends Interaction{
    public Like(Account account, int interactionID, int postID) {
        super(account, interactionID, postID);
    }
}
