package Homework6;

public class TestQuickSort {
    public TestQuickSort(){

    }
    /**
     * testing quick sort with base case
     */
    public void bestCaseQuick(){
        String str = "x yy qqq ssss zzzzz";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        QuickSort qs = new QuickSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        qs.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start1 = System.nanoTime();
        qs.sort();
        double elapsedTime = (System.nanoTime() - start1)/1000000.0;
        System.out.println("(Quick sort best case) Elapsed Time in mili seconds: "+ (elapsedTime));
        qs.printSortedMap();
    }
    /**
     * testing quick sort with worst case
     */
    public void worstCaseQuick(){
        String str = "xxxxx yyyy qqq ss z";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        QuickSort qs = new QuickSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        qs.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start1 = System.nanoTime();
        qs.sort();
        double elapsedTime = (System.nanoTime() - start1)/1000000.0;
        System.out.println("(Quicksort worst case) Elapsed Time in mili seconds: "+ (elapsedTime));
        qs.printSortedMap();
    }

    /**
     * testing quick sort with average case
     */
    public void averageCaseQuick(){

        String str = "zzzzz x qqq yy ssss ";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        QuickSort qs = new QuickSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        qs.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start1 = System.nanoTime();
        qs.sort();
        double elapsedTime = (System.nanoTime() - start1)/1000000.0;
        System.out.println("(Quick sort Average case) Elapsed Time in mili seconds: "+ (elapsedTime));
        qs.printSortedMap();
    }

}
