package Homework6;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/**
 * The QuickSort class implements the Quick Sort algorithm for sorting an array of integers.
 * It provides a method to perform Quick Sort and generate a new sorted array.
 */
public class QuickSort {
    private myMap originalMap;
    private myMap sortedMap;
    private List<String> aux;
    /**
     * Constructs a QuickSort object with the original map.
     *
     * @param originalMap The original map to be sorted.
     */
    public QuickSort(myMap originalMap) {
        this.originalMap = originalMap;
        this.sortedMap = new myMap();
        this.aux = new ArrayList<>(this.originalMap.map.keySet());
    }

    /**
     * Sorts the original map using the Quick Sort algorithm.
     */
    public void sort() {
        quickSortHelper(0, aux.size() - 1);
        generateNewMap();
    }

    private void quickSortHelper(int low, int high) {
        if (low < high) {
            int partitionIndex = partition(low, high);
            quickSortHelper(low, partitionIndex - 1);
            quickSortHelper(partitionIndex + 1, high);
        }
    }

    private int partition(int low, int high) {
        int pivot = originalMap.map.get(aux.get(high)).count;
        int i = (low - 1);

        for (int j = low; j < high; j++) {
            if (originalMap.map.get(aux.get(j)).count < pivot) {
                i++;
                String temp = aux.get(i);
                aux.set(i, aux.get(j));
                aux.set(j, temp);
            }
        }

        String temp = aux.get(i + 1);
        aux.set(i + 1, aux.get(high));
        aux.set(high, temp);

        return i + 1;
    }

    private void generateNewMap() {
        for (String key : aux) {
            sortedMap.assign(key, originalMap.map.get(key).words);
        }
    }
    public void printOriginalArray(){
        for (Map.Entry<String, info> e : originalMap.map.entrySet())
            System.out.println("Letter: " + e.getKey() + " - Count: "
                    + e.getValue().count + " - Words: " + e.getValue().words);
    }
    public void printSortedMap() {
        for (Map.Entry<String, info> entry : sortedMap.map.entrySet()) {
            String key = entry.getKey();
            info value = entry.getValue();
            System.out.println("Letter: " + key + " - Count: " + value.count + " - Words: " + value.words);
        }
    }


}
