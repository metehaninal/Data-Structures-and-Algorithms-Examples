package Homework6;

public class TestBubbleSort {
    public TestBubbleSort(){}

    /**
     * testing bubble sort with best case
     */
    public void bestCaseBubble(){
        String str = "x yy qqq ssss zzzzz";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        BubbleSort bs = new BubbleSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        bs.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start2 = System.nanoTime();
        bs.sort();
        double elapsedTime2 = (System.nanoTime() - start2)/1000000.0;
        System.out.println("(Bubble best case) Elapsed Time in mili seconds: "+ (elapsedTime2));
        bs.printSortedMap();
    }

    /**
     * testing bubble sort with worst case
     */
    public void worstCaseBubble(){
        String str = "xxxxx yyyy qqq ss z";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        BubbleSort bs = new BubbleSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        bs.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start2 = System.nanoTime();
        bs.sort();
        double elapsedTime2 = (System.nanoTime() - start2)/1000000.0;
        System.out.println("(Bubble worst case) Elapsed Time in mili seconds: "+ (elapsedTime2));
        bs.printSortedMap();
    }
    /**
     * testing bubble sort with average case
     */
    public void averageCaseBubble(){
        String str = "zzzzz x qqq yy ssss ";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        BubbleSort bs = new BubbleSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        bs.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start2 = System.nanoTime();
        bs.sort();
        double elapsedTime2 = (System.nanoTime() - start2)/1000000.0;
        System.out.println("(Bubble average case) Elapsed Time in mili seconds: "+ (elapsedTime2));
        bs.printSortedMap();
    }

}
