package Homework6;

public class TestInsertionSort {
    public TestInsertionSort(){}

    /**
     * testing insertion sort with best case
     */
    public void bestCaseInsertion(){
        String str = "x yy qqq ssss zzzzz";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        InsertionSort is = new InsertionSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        is.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start2 = System.nanoTime();
        is.sort();
        double elapsedTime2 = (System.nanoTime() - start2)/1000000.0;
        System.out.println("(Insertion best case) Elapsed Time in mili seconds: "+ (elapsedTime2));
        is.printSortedMap();

    }

    /**
     * testing insertion sort with worst case
     */
    public void worstCaseInsertion(){
        String str = "xxxxx yyyy qqq ss z";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        InsertionSort is = new InsertionSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        is.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start2 = System.nanoTime();
        is.sort();
        double elapsedTime2 = (System.nanoTime() - start2)/1000000.0;
        System.out.println("(Insertion worst case) Elapsed Time in mili seconds: "+ (elapsedTime2));
        is.printSortedMap();
    }

    /**
     * testing insertion sort with avg case
     */
    public void averageCaseInsertion(){
        String str = "zzzzz x qqq yy ssss ";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        InsertionSort is = new InsertionSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        is.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start2 = System.nanoTime();
        is.sort();
        double elapsedTime2 = (System.nanoTime() - start2)/1000000.0;
        System.out.println("(Insertion avg case) Elapsed Time in mili seconds: "+ (elapsedTime2));
        is.printSortedMap();
    }

}
