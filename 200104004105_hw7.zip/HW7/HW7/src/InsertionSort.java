package Homework6;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/**
 * The InsertionSort class implements the Insertion Sort algorithm for sorting an array of integers.
 * It provides a method to perform Insertion Sort and generate a new sorted array.
 */
public class InsertionSort {
    private myMap originalMap;
    private myMap sortedMap;
    private List<String> aux;

    /**
     * Constructs an InsertionSort object with the original map.
     *
     * @param originalMap The original map to be sorted.
     */
    public InsertionSort(myMap originalMap) {
        this.originalMap = originalMap;
        this.sortedMap = new myMap();
        this.aux = new ArrayList<>(this.originalMap.map.keySet());
    }

    /**
     * Sorts the original map using the Insertion Sort algorithm.
     */
    public void sort() {
        //implementation of algo
        int n = aux.size();
        for (int i = 1; i < n; ++i) {
            String key = aux.get(i);
            int j = i - 1;
            while (j >= 0 && originalMap.map.get(aux.get(j)).count > originalMap.map.get(key).count) {
                aux.set(j + 1, aux.get(j));
                j = j - 1;
            }
            aux.set(j + 1, key);
        }
        generateNewMap();
    }
    /**
     * Generates a new sorted map based on the sorted auxiliary list.
     */
    private void generateNewMap() {
        for (String key : aux) {
            sortedMap.assign(key, originalMap.map.get(key).words);
        }
    }

    public void printOriginalArray(){
        for (Map.Entry<String, info> e : originalMap.map.entrySet())
            System.out.println("Letter: " + e.getKey() + " - Count: "
                    + e.getValue().count + " - Words: " + e.getValue().words);
    }
    /**
     * Prints the sorted map.
     */
    public void printSortedMap() {
        for (Map.Entry<String, info> entry : sortedMap.map.entrySet()) {
            String key = entry.getKey();
            info value = entry.getValue();
            System.out.println("Letter: " + key + " - Count: " + value.count + " - Words: " + value.words);
        }
    }


}

