package Homework6;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/**
 * The BubbleSort class implements the Bubble Sort algorithm for sorting an array of integers.
 * It provides a method to perform Bubble Sort and generate a new sorted array.
 */
public class BubbleSort {
    private myMap originalMap;
    private myMap sortedMap;
    private List<String> aux;
    /**
     * Constructs a BubbleSort object with the original map.
     *
     * @param originalMap The original map to be sorted.
     */
    public BubbleSort(myMap originalMap) {
        this.originalMap = originalMap;
        this.sortedMap = new myMap();
        this.aux = new ArrayList<>(this.originalMap.map.keySet());
    }

    /**
     * Sorts the original map using the Bubble Sort algorithm.
     */
    public void sort() {
        int n = aux.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (originalMap.map.get(aux.get(j)).count > originalMap.map.get(aux.get(j + 1)).count) {
                    String temp = aux.get(j);
                    aux.set(j, aux.get(j + 1));
                    aux.set(j + 1, temp);
                }
            }
        }
        generateNewMap();
    }
    /**
     * Generates a new sorted map based on the sorted auxiliary list.
     */
    private void generateNewMap() {
        for (String key : aux) {
            sortedMap.assign(key, originalMap.map.get(key).words);
        }
    }
    /**
     * Prints the sorted map.
     */
    public void printSortedMap() {
        for (Map.Entry<String, info> entry : sortedMap.map.entrySet()) {
            String key = entry.getKey();
            info value = entry.getValue();
            System.out.println("Letter: " + key + " - Count: " + value.count + " - Words: " + value.words);
        }
    }

    public void printOriginalArray(){
        for (Map.Entry<String, info> e : originalMap.map.entrySet())
            System.out.println("Letter: " + e.getKey() + " - Count: "
                    + e.getValue().count + " - Words: " + e.getValue().words);
    }
}
