package Homework6;


public class main {

	public static void main(String[] args) { 

		TestQuickSort testQuick = new TestQuickSort();
		testQuick.worstCaseQuick();
		testQuick.bestCaseQuick();
		testQuick.averageCaseQuick();

		TestBubbleSort testBubble = new TestBubbleSort();
		testBubble.bestCaseBubble();
		testBubble.worstCaseBubble();
		testBubble.averageCaseBubble();


	}
}