package Homework6;

public class TestSelectionSort {
    public TestSelectionSort(){}

    /**
     * testing selection sort with best case
     */
    public void bestCaseSelection(){
        String str = "x yy qqq ssss zzzzz";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        SelectionSort ss = new SelectionSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        ss.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start3 = System.nanoTime();
        ss.sort();
        double elapsedTime3 = (System.nanoTime() - start3)/1000000.0;
        System.out.println("(Selection best case) Elapsed Time in mili seconds: "+ (elapsedTime3));
        ss.printSortedMap();
    }
    /**
     * testing selection sort with worst case
     */
    public void worstCaseSelection(){
        String str = "xxxxx yyyy qqq ss z";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        SelectionSort ss = new SelectionSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        ss.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start3 = System.nanoTime();
        ss.sort();
        double elapsedTime3 = (System.nanoTime() - start3)/1000000.0;
        System.out.println("(Selection Worst Case) Elapsed Time in mili seconds: "+ (elapsedTime3));
        ss.printSortedMap();
    }
    /**
     * testing selection sort with avg case
     */
    public void averageCaseSelection(){
        String str = "zzzzz x qqq yy ssss ";
        myMap newMapObj = new myMap();
        newMapObj.buildMap(str);
        System.out.println("Original String:\t" + str);
        System.out.println("Preprocessed String:\t" + newMapObj.str);
        SelectionSort ss = new SelectionSort(newMapObj);

        System.out.println("\n\nThe original (unsorted) map:");
        ss.printOriginalArray();
        System.out.println("\n\nThe sorted map:");
        double start3 = System.nanoTime();
        ss.sort();
        double elapsedTime3 = (System.nanoTime() - start3)/1000000.0;
        System.out.println("(Selection Avg case) Elapsed Time in mili seconds: "+ (elapsedTime3));
        ss.printSortedMap();
    }
}
