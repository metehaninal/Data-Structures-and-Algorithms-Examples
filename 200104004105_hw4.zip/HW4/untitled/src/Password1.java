import java.util.EmptyStackException;
import java.util.Stack;

public class Password1 {
    private String password;

    /**
     * Creates a new Password object with the specified password string.
     *
     * @param password the password string to set
     * @throws IllegalArgumentException if the password string is not valid according to the password requirements
     */
    public Password1(String password){
        if (isValidPassword(password)) {
            //System.out.println("It is valid pasword!");
            this.password = password;
        } else {
            throw new IllegalArgumentException("Invalid password");
        }
    }
    /**
     * Gets the password string.
     *
     * @return the password string
     */
    public String getPassword() {
        return password;
    }
    /**
     * Sets the password string.
     *
     * @param password the new password string to set
     * @throws IllegalArgumentException if the password string is not valid according to the password requirements
     */
    public void setPassword(String password){
        if (isValidPassword(password)) {
            this.password = password;
        } else {
            throw new IllegalArgumentException("Invalid password");
        }
    }

    /**
     * Checks whether a given password string is valid according to the password requirements.
     *
     * @param password the password string to check
     * @return true if the password string is valid, false otherwise
     * @throws NullPointerException if the password string is null
     */
    public boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }

        int count = 0;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (!Character.isLetter(c) && c != '{' && c != '}' && c != '[' && c != ']' && c != '(' && c != ')') {
                return false;
            }
            if (c == '{' || c == '}' || c == '[' || c == ']' || c == '(' || c == ')') {
                count++;
            }
        }

        return count >= 2;
    }



    private static final String OPEN = "([{";
    private static final String CLOSE = ")]}";

    /**
     * Checks whether the given character is an opening symbol, which includes parentheses, brackets, and braces.
     *
     * @param ch the character to check
     * @return true if the character is an opening symbol, false otherwise
     */
    private static boolean isOpen(char ch) {
        return OPEN.indexOf(ch) > -1;
    }
    /**
     * Checks whether the given character is a closing symbol, which includes parentheses, brackets, and braces.
     *
     * @param ch the character to check
     * @return true if the character is a closing symbol, false otherwise
     */
    private static boolean isClose(char ch) {
        return CLOSE.indexOf(ch) > -1;
    }
    /**
     * Checks whether the given expression with parentheses, brackets, and braces is balanced or not.
     *
     * This method uses a stack to keep track of opening symbols in the expression. For each closing symbol, it pops the
     * top symbol from the stack and checks whether it is the matching opening symbol. If it is, it continues to the next
     * symbol. If it is not, the method returns false. If the stack is not empty at the end of the iteration, the method
     * also returns false, indicating that there is a closing symbol without an opening symbol.
     *
     * @param expression the input expression to check for balance
     * @return true if the expression is balanced, false otherwise
     * @throws EmptyStackException if there is a closing symbol without an opening symbol
     */
    public boolean isBalanced(String expression) {
        // Create an empty stack.
        Stack<Character> s = new Stack<Character>();
        boolean balanced = true;
        try {
            int index = 0;
            while (balanced && index < expression.length()) {
                char nextCh = expression.charAt(index);
                if (isOpen(nextCh)) {
                    s.push(nextCh);
                } else if (isClose(nextCh)) {
                    char topCh = s.pop();
                    balanced =
                            OPEN.indexOf(topCh) == CLOSE.indexOf(nextCh);
                }
                index++;
            }
        } catch (EmptyStackException ex) {
            balanced = false;
        }
        return (balanced && s.empty());
    }
    /**
     * Determines if a palindrome can be formed from the characters in the given password string,
     * after removing any bracket characters.
     *
     * @param password the password string to check
     * @return true if a palindrome can be formed, false otherwise
     */

    public boolean isPalindromePossible(String password) {
        // Remove brackets from the password
        String str = "";
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (c == '(' || c == ')' || c == '[' || c == ']' || c == '{' || c == '}') {
                continue;
            }
            str.concat(String.valueOf(c));
        }

        // Base case: if the length of the string is 0 or 1, it is a palindrome
        if (str.length() <= 1) {
            return true;
        }

        // Recursive case: check if the first and last characters match, and recursively check the middle substring
        char first = str.charAt(0);
        char last = str.charAt(str.length() - 1);
        if (first == last) {
            return isPalindromePossible(str.substring(1, str.length() - 1));
        } else {
            return false;
        }
    }


}
