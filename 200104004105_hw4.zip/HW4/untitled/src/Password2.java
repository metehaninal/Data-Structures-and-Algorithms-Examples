public class Password2 {
    private int password2;
    private int[] denominations;

    public int[] getDenominations() {
        return denominations;
    }

    public void setDenominations(int[] denominations) {
        this.denominations = denominations;
    }

    public int getPassword2() {
        return password2;
    }

    public void setPassword2(int password2) {
        this.password2 = password2;
    }

    public Password2(int n,int[] denominations) throws Exception {
        if (n>=10 && n<=1000) {
            this.password2 = n;
            this.denominations = denominations;
        }else
            throw InvalidInterval();
    }

    private Exception InvalidInterval() {
        System.out.println("Enter a password between 10 - 1000");
        return null;
    }
    /**
     * Checks whether the given password can be formed using the specified set of denominations.
     *
     * @param password The password to be checked.
     * @param denominations An array of integers representing the set of denominations that can be used to form the password.
     * @return {@code true} if the password can be formed using the specified denominations, {@code false} otherwise.
     */
    public boolean isExactDivision(int password, int[] denominations) {
        int[] coefficients = new int[denominations.length];
        for (int i = denominations.length - 1; i >= 0; i--) {
            while (password >= denominations[i]) {
                password -= denominations[i];
                coefficients[i]++;
            }
        }
        return password == 0;
    }



}
