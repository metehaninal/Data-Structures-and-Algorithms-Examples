public class Test {
    private Username username;
    private Password1 password1;
    private Password2 password2;

    public Username getUsername() {
        return username;
    }

    public void setUsername(Username username) {
        this.username = username;
    }

    public Password1 getPassword1() {
        return password1;
    }

    public void setPassword1(Password1 password1) {
        this.password1 = password1;
    }

    public Password2 getPassword2() {
        return password2;
    }

    public void setPassword2(Password2 password2) {
        this.password2 = password2;
    }

    public Test(Username u, Password1 pas1, Password2 pas2){
        this.username = u;
        this.password1= pas1;
        this.password2 = pas2;
    }
    public void call(){
        if (this.usernameCheck() && this.pass1Check() && this.pass2Check()){
            System.out.println("the door is opening");
            System.out.println("***********************************");
        }else {
            this.usernameCheck();
            this.pass1Check();
            this.pass2Check();
            System.out.println("***********************************");
        }
    }
    public boolean usernameCheck(){
        if (!this.username.isLetterString(this.username.getUsername())){
            System.out.println("the username is invalid due to WHOLE CHARS ARE NOT LETTER");
            return false;
        }
        if (!this.username.containsUserNameSpirit(this.username.getUsername(), this.password1.getPassword())){
            System.out.println("The password1 is invalid due to PASSWORD DOESN'T CONTAIN A CHAR FROM USERNAME ");
            return false;
        }
        return true;

    }


    public boolean pass1Check(){
        if (!this.password1.isValidPassword(this.password1.getPassword())){
            System.out.println("the string password is invalid due to LENGTH or at least 2 parantheses");
            return false;
        }
        if (!this.password1.isBalanced(this.password1.getPassword())){
            System.out.println("the string password is invalid due to OPEN and CLOSE PARANTHESESS are NOT BALANCED");
            return false;
        }
        if (!this.password1.isPalindromePossible(this.password1.getPassword())){
            System.out.println("the string password is invalid due to PALINDOROME is NOT possible");
            return false;
        }
        return  true;
    }

    public boolean pass2Check(){
        if (!this.password2.isExactDivision(this.password2.getPassword2(),this.password2.getDenominations())){
            System.out.println("The int password is invalid due to  EXACT DIVISION is not possible! Try again ");
            return false;
        }
        return true;
    }
}
