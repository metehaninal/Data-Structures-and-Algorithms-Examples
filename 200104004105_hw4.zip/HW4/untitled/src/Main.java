public class Main {
    public static void main(String[] args) throws Exception {

        Username user = new Username("alex");
        Password1 password1 = new Password1("{[(abacaba)]}");
        Password2 password2 = new Password2(75, new int[]{4, 17, 29});
        Test test1 = new Test(user,password1,password2);
        //test1.call();

        Username u = new Username("gokhan");
        Password1 p = new Password1("{ab[bac]aaba}");
        /*----------------------------------------------*/
        System.out.println(p.isPalindromePossible(p.getPassword()));
        System.out.println(p.isBalanced(p.getPassword()));
        System.out.println(p.isValidPassword(p.getPassword()));
        /*-------------------------------------------------*/
        Password2 p2 = new Password2(54,new int[]{4, 17, 29});
        Test test2 = new Test(u,p,p2);
        test2.call();



    }
}


