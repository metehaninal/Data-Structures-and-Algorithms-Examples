import java.util.Stack;

public class Username {
    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Username(String username) {
        this.username = username;
    }


    /**
     * Checks whether the given string consists entirely of alphabetical letters.
     *
     * @param s the string to be checked
     * @return true if the string contains only letters, false otherwise
     */
    public  boolean isLetterString(String s) {
        // Base case: if the string is empty, return false
        if (s.length() == 0) {
            return false;
        }
        // Base case: if the string has only one character, check if it is a letter
        if (s.length() == 1) {
            return Character.isLetter(s.charAt(0));
        }
        // Recursive case: check if the first character is a letter and the rest of the string is also a letter string
        return Character.isLetter(s.charAt(0)) && isLetterString(s.substring(1));
    }




    /**
     * Checks if a given password contains at least one letter from the username.
     *
     * @param username the String username to check against the password
     * @param password the String password to check for a matching letter
     * @return true if the password contains at least one letter from the username, false otherwise
     */
    public boolean containsUserNameSpirit(String username, String password) {
        // Create a stack to hold the characters of the username
        Stack<Character> stack = new Stack<>();
        for (char c : username.toCharArray()) {
            stack.push(c);
        }

        // Check if the password contains at least one character from the username
        for (char c : password.toCharArray()) {
            if (stack.contains(c)) {
                return true;
            }
        }

        return false;
    }
}
